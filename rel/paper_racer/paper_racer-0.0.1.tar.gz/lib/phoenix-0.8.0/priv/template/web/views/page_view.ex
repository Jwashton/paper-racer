defmodule <%= application_module %>.PageView do
  use <%= application_module %>.View
end
